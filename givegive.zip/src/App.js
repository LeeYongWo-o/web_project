import React from 'react';
// 라우터(화면 교체기) 도구들 불러오기
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
// 방금 만든 수요자 로그인 파일 불러오기
import LoginBuyer from './auth/login_buyer'; 
import SignupBuyer from './auth/signup_buyer';

function Home() {
  const navigate = useNavigate(); 

  return (
    <div className="bg-gradient-to-b from-[#E9F0FF] to-[#FFFFFF] min-h-screen flex flex-col items-center justify-center w-full px-10" style={{ fontFamily: "'Noto Sans KR', sans-serif", letterSpacing: "-0.05em" }}>
      
      <h1 className="text-[64px] font-bold text-[#0047FF] mb-2">나눔 플랫폼 키오스크</h1>
      <p className="text-[32px] text-[#666666] mb-20 font-medium">원하시는 서비스를 선택해주세요</p>

      <div className="flex gap-12 w-full max-w-[1150px] justify-center">
        
        {/* 수요자 버튼 */}
        <button 
          onClick={() => navigate('/login-buyer')} 
          className="bg-white w-[500px] py-20 rounded-[48px] shadow-[0_20px_50px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all flex flex-col items-center border border-white"
        >
          <div className="w-48 h-48 bg-[#E9F0FF] rounded-full flex items-center justify-center mb-10">
            <svg width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#0047FF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>
          </div>
          <h2 className="text-[52px] font-bold text-[#333333] mb-4">수요자</h2>
          <p className="text-[26px] text-gray-400 text-center leading-tight">필요한 물품을 찾아보<br />세요</p>
        </button>

        {/* 기부자 버튼 */}
        <button 
          onClick={() => navigate('/login-seller')} 
          className="bg-white w-[500px] py-20 rounded-[48px] shadow-[0_20px_50px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all flex flex-col items-center border border-white"
        >
          <div className="w-48 h-48 bg-[#E8F9F1] rounded-full flex items-center justify-center mb-10">
            <svg width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="8" r="4"></circle>
              <path d="M20 21c0-4.418-3.582-8-8-8s-8 3.582-8 8"></path>
            </svg>
          </div>
          <h2 className="text-[52px] font-bold text-[#333333] mb-4">기부자</h2>
          <p className="text-[26px] text-gray-400 text-center leading-tight">나눔 물품을 등록하세<br />요</p>
        </button>

      </div>
    </div>
  );
}

// 라우터
function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/*홈화면 */}
        <Route path="/" element={<Home />} />
        {/*수요자*/}
        <Route path="/login-buyer" element={<LoginBuyer />} />
        {/*수요자 회원가입*/}
        <Route path="/signup-buyer" element={<SignupBuyer />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;