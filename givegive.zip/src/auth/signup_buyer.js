import React from 'react';
import { useNavigate } from 'react-router-dom';

function SignupBuyer() {
  const navigate = useNavigate();

  return (
    <div className="bg-[#F9FAFB] min-h-screen flex items-center justify-center p-6" style={{ fontFamily: "'Noto Sans KR', sans-serif", letterSpacing: "-0.05em" }}>
      <div className="bg-white w-full max-w-[600px] rounded-[40px] shadow-sm p-12 flex flex-col">
        
        {/* 뒤로가기 버튼 */}
        <button 
          onClick={() => navigate('/login-buyer')} 
          className="mb-10 self-start hover:bg-gray-100 p-2 rounded-full transition-all"
        >
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>

        <div className="text-center mb-10">
          <h1 className="text-[42px] font-bold text-[#333] mb-2">수요자 회원가입</h1>
          <p className="text-[18px] text-gray-400">서비스 이용을 위해 정보를 입력해주세요</p>
        </div>

        {/* 입력 영역: 스크롤 */}
        <div className="space-y-6 flex-1 overflow-y-auto pr-2 max-h-[500px] custom-scrollbar">
          {[
            { label: '이름', type: 'text', placeholder: '이름을 입력하세요' },
            { label: '아이디', type: 'text', placeholder: '아이디를 입력하세요' },
            { label: '비밀번호', type: 'password', placeholder: '비밀번호를 입력하세요' },
            { label: '비밀번호 확인', type: 'password', placeholder: '비밀번호를 한번 더 입력하세요' },
            { label: '전화번호', type: 'tel', placeholder: '전화번호를 입력하세요 (- 제외)' },
            { label: '사는 지역', type: 'text', placeholder: '예: 서울시 강남구' },
          ].map((field, index) => (
            <div key={index} className="space-y-2">
              <label className="text-[16px] font-bold text-[#333] ml-1">{field.label}</label>
              <input 
                type={field.type} 
                placeholder={field.placeholder} 
                className="w-full border-2 border-gray-100 rounded-[15px] px-5 py-4 outline-none focus:border-[#0047FF] transition-all"
              />
            </div>
          ))}
        </div>

        <button 
          onClick={() => alert('가입이 완료되었습니다!')}
          className="w-full bg-[#0047FF] text-white py-5 rounded-[18px] text-[22px] font-bold mt-10 transition-all active:scale-[0.98] shadow-md"
        >
          가입 완료
        </button>
      </div>
    </div>
  );
}

export default SignupBuyer;